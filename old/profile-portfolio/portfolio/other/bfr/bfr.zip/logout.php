<?php

	require_once("soporte.php");
	$auth->logout();
	header("Location:form.php");exit;
	?>
