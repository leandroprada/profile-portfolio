<?php
	require_once("soporte.php");

?>

<nav id="mainNav" class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="glyphicon glyphicon-menu-hamburger"></span>
            </button>
            <a class="navbar-brand page-scroll" href="form.php">BFR</a>
						<img src="images/amamanta.jpg" alt="" height="50px" />
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

						<ul class="nav navbar-nav navbar-right">
							<li><h4 style="padding-right:30px">Registro de Amamantamiento </h4></li>
<li><h4 class="navbar"><?php if ($auth->estaLogueado()) { ?>
	 <?php
	$usuario = $repoUsuarios->traerUsuarioPorEmail($_SESSION["usuarioLogueado"]);
echo "Hola ".($usuario->getEmail()). " ¡Bienvenido/a!";
}?></h4></li>

<?php if ($auth->estaLogueado()) { ?>
								<button type="button" class="btn btn-default navbar-btn" ><a href="logout.php">Logout</a></button>

								<?php }?>

<?php if (!$auth->estaLogueado()) { ?>
								<button type="button" class="btn btn-default navbar-btn"><a href="login2.php">Ingresa</a></button>

                <button type="button" class="btn btn-default navbar-btn" ><a href="registrate.php">Registrate</a></button>
<?php }?>
						</ul>
            </ul>
        </div>
    </div>
</nav>
